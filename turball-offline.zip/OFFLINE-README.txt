Turball offline package

Requirements: Node.js 18 or newer. No npm packages are required.

Run from this directory:
  node serve.mjs

Then open http://127.0.0.1:4173 in a browser. To use a different port:
  PORT=8080 node serve.mjs

The package includes game modules, arena manifests, models, skyboxes, textures,
audio, and UI assets mirrored for local use. Internet access is not needed after
the package has been downloaded.

Online services such as accounts, multiplayer, clips, and store inventory are
not included. The local server reports those API routes as unavailable.